import {Component, OnInit} from '@angular/core';
import {EmployeeService} from './business-logic/employee.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'angular-project-architecture';

  constructor(private employeeService: EmployeeService) {
  }

  ngOnInit(): void {
    this.employeeService.getEmployeeList().then(res => {
      console.log(res);
    }).catch(err => {
      console.log(err);
    });
  }
}
