import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {catchError, map} from 'rxjs/operators';
import {environment} from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class EmployeeDataService {

  constructor(private http: HttpClient) {
  }

  getEmployeeList(): Promise<any> {
    return this.http.get(environment.apiUrl + 'users').pipe(
      catchError(err => {
        return err;
      }),
      map((response) => {
        return response;
      })
    ).toPromise();
  }
}
