import {Injectable} from '@angular/core';
import {EmployeeDataService} from '../data-services/employee-data.service';
import {Employee} from '../business-entities/employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private employeeDataService: EmployeeDataService) {
  }

  getEmployeeList(): Promise<Employee> {
    return this.employeeDataService.getEmployeeList();
  }
}
