export class Employee {
  id: number;
  name: string;
  number: number;
  address: string;
}
