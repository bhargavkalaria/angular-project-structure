import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {AppComponent} from './app.component';

const routes: Routes = [
    {
      path: '',
      component: AppComponent
    },
    {
      path: 'flow-builder',
      loadChildren: () => import('../../projects/flow-builder/src/app/app.module').then(res => res.FlowBuilderModule)
    },
    {
      path: 'lise',
      loadChildren: () => import('../../projects/lise/src/app/app.module').then(res => res.LiseModule)
    },
    {
      path: 'dialog-flow',
      loadChildren: () => import('../../projects/dialog-flow/src/app/app.module').then(res => res.DialogFlowModule)
    }
  ]
;

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
}
